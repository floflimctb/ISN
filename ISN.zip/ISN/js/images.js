function RedirectionJavascript() {
	document.location.href = '../html/qcm.html'; 
}